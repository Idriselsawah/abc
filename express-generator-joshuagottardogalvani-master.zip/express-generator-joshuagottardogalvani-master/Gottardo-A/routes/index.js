var express = require('express');
var router = express.Router();
const peopleJson = require('../people.json');

router.get('/people', function(req, res, next) {
  res.render('people', { p: peopleJson.people });
});

module.exports = router;
