var express = require('express');
var router = express.Router();
var createError = require('http-errors');
const peopleJson = require('../people.json');

/* GET home page. */
router.get('/people', function (req, res, next) {
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify(peopleJson));
});

router.get('/people/:email', function (req, res, next) {
    const person = peopleJson.people.find(p => p.email === req.params.email);

    if (typeof person === "undefined") {
        return next(createError(404, 'La risorsa richiesta non è stata trovata ma in futuro potrebbe essere disponibile.'));
    } else {
        res.setHeader('Content-Type', 'application/json');
        res.send(JSON.stringify(person));
    }
});

module.exports = router;